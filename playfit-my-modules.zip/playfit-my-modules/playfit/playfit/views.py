from django.shortcuts import render
from distributor.models import Distributor
from product.models import Product, ProductCategory
from distributor.forms import DistributorForm

def DistributorDashboard(request, *args, **kwargs):
    if request.method == 'GET':
        distributors =  Distributor.objects.all()
        product_category = ProductCategory.objects.all()
        products = Product.objects.all()
        context = {
            'distributors': distributors,
            'product_category': product_category,
            'products': products,
            'distributor_id': kwargs['distributor_id'],
            'distributor_form': DistributorForm()
        }
        return render(request, 'dashboard.html', context)
from django.contrib import admin
from django.urls import path, include
from .views import DistributorDashboard

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('distributor.urls')),
    path('', include('product.urls')),
    path('dashboard/<int:distributor_id>/', DistributorDashboard, name='distributor_dashboard')
]

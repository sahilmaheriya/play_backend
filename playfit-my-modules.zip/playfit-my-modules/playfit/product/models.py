from django.db import models


# image_url
# category
# created_date
# updated_date
# is_active

class ProductCategory(models.Model):
    name = models.CharField(max_length=122)

    def __str__(self):
        return self.name


class Product(models.Model):
    product_name = models.CharField(max_length=122)
    category = models.ForeignKey(ProductCategory, on_delete=models.SET_NULL, null=True, blank=True)
    image_url = models.URLField(blank=True, null=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.product_name
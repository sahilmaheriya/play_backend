from django.shortcuts import render
from .models import Product
from django.http import JsonResponse
import json



def get_product(request):
    if request.method == 'POST':
        products = Product.objects.filter(category=request.POST.get('category'))
        if products:
            data = []
            for product in products:    
                item = {
                    'product_id':product.id,
                    'product_name':product.product_name
                }
                data.append(item)
            res = data
        else:
            res = 'No Product Found'
        return JsonResponse({'data':res})
from django.contrib import admin
from .models import Distributor


admin.site.register(Distributor)
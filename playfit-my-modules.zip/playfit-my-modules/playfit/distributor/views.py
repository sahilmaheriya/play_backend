from django.shortcuts import render
from .models import Distributor
from .forms import DistributorForm
from django.shortcuts import redirect, render


def DistributorView(request):
    if request.method == 'GET':
        data =  Distributor.objects.all()
        return render(request, 'dashboard.html', {'data':data})
    
    if request.method == 'POST':
        distributor_form = DistributorForm(request.POST)
        if distributor_form.is_valid():
            distributor = distributor_form.save()
            distributor.parent_id=Distributor.objects.filter(id=request.POST['distributor_id']).first()
            distributor.save()
        else:
            return redirect(request.META.get('HTTP_REFERER'))
        return redirect(request.META.get('HTTP_REFERER'))
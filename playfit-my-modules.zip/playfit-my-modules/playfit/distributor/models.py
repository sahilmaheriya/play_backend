from django.db import models

DISTRIBUTOR_TYPE = (
    ('SuperDistributor', 'SuperDistributor'),
    ('MasterDistributor', 'MasterDistributor'),
)

# super Distributor
# master

# name
# type
# created
# modify


class Distributor(models.Model):
    name = models.CharField(max_length=122)
    parent_id = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='distributor')
    distrubutor_type = models.CharField(choices=DISTRIBUTOR_TYPE ,max_length=18, null=True, blank=True)
    email = models.EmailField(max_length=122)
    created_by = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True, related_name='created')
    updated_by = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True, related_name='updated')

    def __str__(self):
        return self.name


    # md_name = models.ForeignKey('self', on_delete=models.CASCADE, blank=True, null=True)
    # category = models.CharField(choices=CATEGORY_CHOICES, max_length=10)
    # product_sku = models.ForeignKey(Product, on_delete=models.CASCADE)
    # serial_number = models.CharField(max_length=122)
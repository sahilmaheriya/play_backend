from django import forms
from .models import Distributor
from django.forms import widgets
from django.db.models import fields


class DistributorForm(forms.ModelForm):
    class Meta:
        model = Distributor
        fields = ['name', 'distrubutor_type', 'email']
        widgets = {
            'name':forms.TextInput(attrs={'class':'form-control my-3'}),
            'distrubutor_type':forms.Select(attrs={'class':'form-control my-3'}),
            'email':forms.EmailInput(attrs={'class':'form-control my-3'})
        }
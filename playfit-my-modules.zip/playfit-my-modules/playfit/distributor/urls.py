from django.contrib import admin
from django.urls import path, include
from .views import DistributorView

urlpatterns = [
    path('create_distributor/', DistributorView, name='create_distributor'),
]
